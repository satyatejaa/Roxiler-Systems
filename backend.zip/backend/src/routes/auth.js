const express = require('express');
const router = express.Router();
const { signup, login, updatePassword } = require('../controllers/auth');
const { authenticate } = require('../middleware/auth');

router.post('/signup', signup);
router.post('/login', login);
router.post('/update-password', authenticate, updatePassword);

module.exports = router;
