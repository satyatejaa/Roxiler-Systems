const express = require('express');
const router = express.Router();
const { authenticate, requireRole } = require('../middleware/auth');
const { listStores, rateStore, ownerRaters } = require('../controllers/stores');

router.get('/', (req,res,next)=>{ next(); }, listStores); // public list, optional auth
router.post('/:storeId/rate', authenticate, rateStore);
router.get('/owner/:storeId/raters', authenticate, requireRole('owner'), ownerRaters);

module.exports = router;
