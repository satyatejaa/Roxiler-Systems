const express = require('express');
const router = express.Router();
const { authenticate, requireRole } = require('../middleware/auth');
const { dashboard, createUser, listUsers, listStores } = require('../controllers/admin');

router.use(authenticate);
router.use(requireRole('admin'));

router.get('/dashboard', dashboard);
router.post('/create-user', createUser);
router.get('/users', listUsers);
router.get('/stores', listStores);

module.exports = router;
