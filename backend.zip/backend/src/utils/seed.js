const { sequelize, User, Store } = require('../models');
const bcrypt = require('bcrypt');

async function seed(){
  await sequelize.sync({ force: true });
  const pass = await bcrypt.hash('Admin@1234', 10);
  const admin = await User.create({ name: 'System Administrator Real Example', email: 'admin@example.com', passwordHash: pass, address: 'HQ Address', role: 'admin' });
  const ownerPass = await bcrypt.hash('Owner@1234', 10);
  const owner = await User.create({ name: 'Store Owner Real Example', email: 'owner@example.com', passwordHash: ownerPass, address: 'Owner address', role: 'owner' });
  const userPass = await bcrypt.hash('User@1234', 10);
  const user = await User.create({ name: 'Normal User Real Example Name', email: 'user@example.com', passwordHash: userPass, address: 'User address', role: 'user' });
  await Store.create({ name: 'Real Sample Store', email: 'store@example.com', address: '123 Main St', ownerId: owner.id });
  console.log('Seeded data');
  process.exit(0);
}

seed().catch(e=>{ console.error(e); process.exit(1); });
