const Joi = require('joi');
const nameSchema = Joi.string().min(20).max(60).required();
const addressSchema = Joi.string().max(400).allow('', null);
const passwordSchema = Joi.string().min(8).max(16).pattern(/[A-Z]/).pattern(/[^A-Za-z0-9]/).required();
const emailSchema = Joi.string().email().required();

const signupSchema = Joi.object({
  name: nameSchema,
  email: emailSchema,
  password: passwordSchema,
  address: addressSchema
});
const loginSchema = Joi.object({ email: emailSchema, password: Joi.string().required() });

module.exports = { signupSchema, loginSchema };
