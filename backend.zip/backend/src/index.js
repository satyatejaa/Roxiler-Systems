require('dotenv').config();
const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const { sequelize } = require('./models');
const authRoutes = require('./routes/auth');
const adminRoutes = require('./routes/admin');
const storeRoutes = require('./routes/stores');

const app = express();
app.use(cors());
app.use(bodyParser.json());

app.use('/api/auth', authRoutes);
app.use('/api/admin', adminRoutes);
app.use('/api/stores', storeRoutes);

const PORT = process.env.PORT || 4000;

async function start(){
  await sequelize.authenticate();
  await sequelize.sync(); // for production, replace with migrations
  console.log('DB connected');
  app.listen(PORT, ()=> console.log('Server listening on', PORT));
}

start().catch(err => { console.error(err); process.exit(1); });
