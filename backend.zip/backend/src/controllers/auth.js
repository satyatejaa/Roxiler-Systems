const bcrypt = require('bcrypt');
const { User } = require('../models');
const { sign } = require('../utils/jwt');
const { signupSchema, loginSchema } = require('../utils/validators');

async function signup(req,res){
  try {
    const { error, value } = signupSchema.validate(req.body);
    if(error) return res.status(400).json({ message: error.details[0].message });
    const { name, email, password, address } = value;
    const hash = await bcrypt.hash(password, 10);
    const u = await User.create({ name, email, passwordHash: hash, address, role: 'user' });
    return res.json({ id: u.id, email: u.email });
  } catch(err){ return res.status(400).json({ message: err.message }); }
}

async function login(req,res){
  try {
    const { error, value } = loginSchema.validate(req.body);
    if(error) return res.status(400).json({ message: error.details[0].message });
    const { email, password } = value;
    const u = await User.findOne({ where: { email } });
    if(!u) return res.status(400).json({ message: 'Invalid credentials' });
    const ok = await bcrypt.compare(password, u.passwordHash);
    if(!ok) return res.status(400).json({ message: 'Invalid credentials' });
    const token = sign({ id: u.id, role: u.role }, { expiresIn: '7d' });
    return res.json({ token, role: u.role, name: u.name, id: u.id });
  } catch(err){ return res.status(400).json({ message: err.message }); }
}

async function updatePassword(req,res){
  try {
    const { oldPassword, newPassword } = req.body;
    if(!oldPassword || !newPassword) return res.status(400).json({ message: 'Missing fields' });
    // basic check for newPassword - reuse validators if needed
    const bcrypt = require('bcrypt');
    const user = await User.findByPk(req.user.id);
    const ok = await bcrypt.compare(oldPassword, user.passwordHash);
    if(!ok) return res.status(400).json({ message: 'Old password incorrect' });
    user.passwordHash = await bcrypt.hash(newPassword, 10);
    await user.save();
    return res.json({ message: 'Password updated' });
  } catch(err){ return res.status(400).json({ message: err.message }); }
}

module.exports = { signup, login, updatePassword };
