const { Store, Rating, User } = require('../models');
const { Op } = require('sequelize');

async function listStores(req,res){
  const { q, sortBy='name', order='ASC', page=1, limit=20 } = req.query;
  const where = q ? { [Op.or]: [
    { name: { [Op.iLike]: `%${q}%` } },
    { address: { [Op.iLike]: `%${q}%` } },
  ] } : {};
  const offset = (page-1)*limit;
  const stores = await Store.findAll({ where, limit: parseInt(limit), offset: parseInt(offset), order: [[sortBy, order]] });
  const out = await Promise.all(stores.map(async s=>{
    const ratings = await s.getRatings();
    const avg = ratings.length ? (ratings.reduce((a,b)=>a+b.value,0)/ratings.length) : null;
    // find user's rating if authenticated
    let userRating = null;
    if(req.user){
      const r = await Rating.findOne({ where: { userId: req.user.id, storeId: s.id } });
      if(r) userRating = r.value;
    }
    return { id: s.id, name: s.name, address: s.address, rating: avg, userRating };
  }));
  return res.json({ rows: out, count: out.length });
}

async function rateStore(req,res){
  const userId = req.user.id;
  const storeId = req.params.storeId;
  const { value } = req.body;
  const intVal = parseInt(value);
  if(!Number.isInteger(intVal) || intVal<1 || intVal>5) return res.status(400).json({ message: 'Rating must be 1-5' });
  let r = await Rating.findOne({ where: { userId, storeId } });
  if(r){ r.value = intVal; await r.save(); return res.json({ message: 'Rating updated' }); }
  r = await Rating.create({ userId, storeId, value: intVal });
  return res.json({ message: 'Rating created' });
}

async function ownerRaters(req,res){
  // owner sees raters for their store
  const storeId = req.params.storeId;
  const store = await Store.findByPk(storeId);
  if(!store) return res.status(404).json({ message: 'Not found' });
  if(store.ownerId !== req.user.id) return res.status(403).json({ message: 'Forbidden' });
  const ratings = await Rating.findAll({ where: { storeId }, include: [{ model: User, attributes: ['id','name','email'] }] });
  const avg = ratings.length ? (ratings.reduce((a,b)=>a+b.value,0)/ratings.length) : null;
  const raters = ratings.map(r=>({ userId: r.User.id, name: r.User.name, email: r.User.email, value: r.value, createdAt: r.createdAt }));
  return res.json({ average: avg, raters });
}

module.exports = { listStores, rateStore, ownerRaters };
