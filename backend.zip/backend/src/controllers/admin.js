const { User, Store, Rating } = require('../models');
const bcrypt = require('bcrypt');
const { Op } = require('sequelize');

async function dashboard(req,res){
  const usersCount = await User.count();
  const storesCount = await Store.count();
  const ratingsCount = await Rating.count();
  return res.json({ usersCount, storesCount, ratingsCount });
}

async function createUser(req,res){
  const { name, email, password, address, role } = req.body;
  if(!name || !email || !password) return res.status(400).json({ message: 'Missing fields' });
  const hash = await bcrypt.hash(password, 10);
  try {
    const u = await User.create({ name, email, passwordHash: hash, address, role: role || 'user' });
    return res.json({ id: u.id, email: u.email });
  } catch(err){ return res.status(400).json({ message: err.message }); }
}

async function listUsers(req,res){
  const { q, sortBy='name', order='ASC', page=1, limit=20 } = req.query;
  const where = q ? { [Op.or]: [
    { name: { [Op.iLike]: `%${q}%` } },
    { email: { [Op.iLike]: `%${q}%` } },
    { address: { [Op.iLike]: `%${q}%` } },
  ] } : {};
  const offset = (page-1)*limit;
  const users = await User.findAndCountAll({
    where,
    attributes: ['id','name','email','address','role'],
    order: [[sortBy, order]],
    limit: parseInt(limit),
    offset: parseInt(offset)
  });
  return res.json(users);
}

async function listStores(req,res){
  const { q, sortBy='name', order='ASC', page=1, limit=20 } = req.query;
  const where = q ? { [Op.or]: [
    { name: { [Op.iLike]: `%${q}%` } },
    { email: { [Op.iLike]: `%${q}%` } },
    { address: { [Op.iLike]: `%${q}%` } },
  ] } : {};
  const offset = (page-1)*limit;
  const stores = await Store.findAll({ where, limit: parseInt(limit), offset: parseInt(offset) });
  // compute rating for each store
  const out = await Promise.all(stores.map(async s=>{
    const ratings = await s.getRatings();
    const avg = ratings.length ? (ratings.reduce((a,b)=>a+b.value,0)/ratings.length) : null;
    return { id: s.id, name: s.name, email: s.email, address: s.address, rating: avg };
  }));
  return res.json({ rows: out, count: out.length });
}

module.exports = { dashboard, createUser, listUsers, listStores };
