const { Sequelize, DataTypes } = require('sequelize');
const sequelize = new Sequelize(process.env.DATABASE_URL || 'postgres://postgres:password@db:5432/fullstack', {
  dialect: 'postgres',
  logging: false,
});

const User = sequelize.define('User', {
  name: { type: DataTypes.STRING(255), allowNull: false },
  email: { type: DataTypes.STRING(255), allowNull: false, unique: true },
  passwordHash: { type: DataTypes.STRING(255), allowNull: false },
  address: { type: DataTypes.TEXT },
  role: { type: DataTypes.ENUM('admin','user','owner'), defaultValue: 'user' }
}, { timestamps: true });

const Store = sequelize.define('Store', {
  name: { type: DataTypes.STRING(255), allowNull: false },
  email: { type: DataTypes.STRING(255) },
  address: { type: DataTypes.TEXT },
}, { timestamps: true });

const Rating = sequelize.define('Rating', {
  value: { type: DataTypes.INTEGER, allowNull: false, validate: { min:1, max:5 } }
}, { timestamps: true });

// associations
User.hasMany(Rating, { foreignKey: 'userId' });
Rating.belongsTo(User, { foreignKey: 'userId' });

Store.hasMany(Rating, { foreignKey: 'storeId' });
Rating.belongsTo(Store, { foreignKey: 'storeId' });

Store.belongsTo(User, { as: 'owner', foreignKey: 'ownerId' });

module.exports = { sequelize, User, Store, Rating };
