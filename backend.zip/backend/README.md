Real Backend - Express + Sequelize (production-oriented)
-------------------------------------------------------
- Docker Compose provided: run `docker-compose up --build` to start PostgreSQL and backend (backend exposes port 4000).
- Env: DATABASE_URL (defaults to postgres://postgres:password@db:5432/fullstack), JWT_SECRET.
- Seed: inside container run `node src/utils/seed.js`.
- Endpoints documented in code. Includes sorting, filtering, pagination for user/store listings.
- Validation with Joi. Role-based access enforced via middleware.
