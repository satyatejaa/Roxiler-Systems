Frontend - React (production-oriented)
-------------------------------------
- Start with `npm install` then `npm start`.
- Set REACT_APP_API_URL to point to backend API if not localhost:4000.
- Includes pages for login, signup, admin dashboard, owner dashboard, and store listings with rating actions.
