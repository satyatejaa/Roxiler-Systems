import React from 'react';
import { Routes, Route, Link } from 'react-router-dom';
import Home from './pages/Home';
import Login from './pages/Login';
import Signup from './pages/Signup';
import AdminDashboard from './pages/AdminDashboard';
import OwnerDashboard from './pages/OwnerDashboard';
import UserStores from './pages/UserStores';

function App(){
  return (<div style={{fontFamily:'Arial'}}>
    <nav style={{padding:10, borderBottom:'1px solid #ccc'}}>
      <Link to='/' style={{marginRight:10}}>Home</Link>
      <Link to='/stores' style={{marginRight:10}}>Stores</Link>
      <Link to='/login' style={{marginRight:10}}>Login</Link>
      <Link to='/signup'>Signup</Link>
    </nav>
    <Routes>
      <Route path='/' element={<Home/>} />
      <Route path='/login' element={<Login/>} />
      <Route path='/signup' element={<Signup/>} />
      <Route path='/admin' element={<AdminDashboard/>} />
      <Route path='/owner' element={<OwnerDashboard/>} />
      <Route path='/stores' element={<UserStores/>} />
    </Routes>
  </div>);
}

export default App;
