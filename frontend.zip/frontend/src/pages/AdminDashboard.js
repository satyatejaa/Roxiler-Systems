import React, { useEffect, useState } from 'react';
import axios from 'axios';
const API = process.env.REACT_APP_API_URL || 'http://localhost:4000/api';
export default function AdminDashboard(){
  const token = localStorage.getItem('token');
  const [stats,setStats]=useState({});
  useEffect(()=>{ fetch(); }, []);
  async function fetch(){ try{ const res = await axios.get(API+'/admin/dashboard', { headers: { Authorization: 'Bearer '+token } }); setStats(res.data); }catch(e){ console.error(e); } }
  return (<div style={{padding:20}}><h3>Admin Dashboard</h3>
    <div>Total Users: {stats.usersCount}</div>
    <div>Total Stores: {stats.storesCount}</div>
    <div>Total Ratings: {stats.ratingsCount}</div>
  </div>);
}
