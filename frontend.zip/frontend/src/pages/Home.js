import React from 'react';
export default function Home(){ return (<div style={{padding:20}}><h2>Welcome — FullStack Real Project</h2><p>Use the navigation to access pages.</p></div>); }
