import React, { useState } from 'react';
import axios from 'axios';
const API = process.env.REACT_APP_API_URL || 'http://localhost:4000/api';

export default function Login(){
  const [email,setEmail]=useState(''); const [password,setPassword]=useState('');
  async function submit(e){ e.preventDefault();
    try {
      const res = await axios.post(API+'/auth/login',{ email, password });
      localStorage.setItem('token', res.data.token);
      localStorage.setItem('role', res.data.role);
      alert('Logged in as '+res.data.role);
    } catch(err){ alert(err.response?.data?.message || err.message); }
  }
  return (<div style={{padding:20}}><h3>Login</h3>
    <form onSubmit={submit}>
      <div><input placeholder='Email' value={email} onChange={e=>setEmail(e.target.value)} /></div>
      <div><input placeholder='Password' type='password' value={password} onChange={e=>setPassword(e.target.value)} /></div>
      <button type='submit'>Login</button>
    </form>
  </div>);
}
