import React, { useState } from 'react';
import axios from 'axios';
const API = process.env.REACT_APP_API_URL || 'http://localhost:4000/api';

export default function Signup(){
  const [name,setName]=useState(''); const [email,setEmail]=useState(''); const [address,setAddress]=useState(''); const [password,setPassword]=useState('');
  async function submit(e){ e.preventDefault();
    try {
      await axios.post(API+'/auth/signup',{ name,email,address,password });
      alert('Signed up — now login');
    } catch(err){ alert(err.response?.data?.message || err.message); }
  }
  return (<div style={{padding:20}}><h3>Signup</h3>
    <form onSubmit={submit}>
      <div><input placeholder='Name (20-60 chars)' value={name} onChange={e=>setName(e.target.value)} /></div>
      <div><input placeholder='Email' value={email} onChange={e=>setEmail(e.target.value)} /></div>
      <div><input placeholder='Address' value={address} onChange={e=>setAddress(e.target.value)} /></div>
      <div><input placeholder='Password (8-16, 1 uppercase, 1 special)' type='password' value={password} onChange={e=>setPassword(e.target.value)} /></div>
      <button type='submit'>Signup</button>
    </form>
  </div>);
}
