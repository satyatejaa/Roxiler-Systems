import React, { useEffect, useState } from 'react';
import axios from 'axios';
const API = process.env.REACT_APP_API_URL || 'http://localhost:4000/api';

export default function UserStores(){
  const [stores,setStores]=useState([]); const [q,setQ]=useState('');
  const token = localStorage.getItem('token');
  useEffect(()=>{ fetch(); }, []);
  async function fetch(){ const res = await axios.get(API+'/stores', { headers: token?{ Authorization: 'Bearer '+token } : {} }); setStores(res.data.rows || res.data); }
  async function rate(id, val){ try{ await axios.post(API+`/stores/${id}/rate`, { value: val }, { headers: { Authorization: 'Bearer '+token } }); alert('Rated'); fetch(); }catch(e){ alert(e.response?.data?.message||e.message); } }
  return (<div style={{padding:20}}>
    <h3>Stores</h3>
    <div><input placeholder='Search name or address' value={q} onChange={e=>setQ(e.target.value)} /> <button onClick={()=>fetch()}>Search</button></div>
    <ul>
      {stores.map(s=> (<li key={s.id} style={{marginBottom:10}}>
        <strong>{s.name}</strong> — {s.address} — Avg: {s.rating||'N/A'} — Your: {s.userRating||'N/A'}
        <div>Rate: {[1,2,3,4,5].map(n=> <button key={n} onClick={()=>rate(s.id,n)} style={{marginLeft:6}}>{n}</button>)}</div>
      </li>))}
    </ul>
  </div>);
}
