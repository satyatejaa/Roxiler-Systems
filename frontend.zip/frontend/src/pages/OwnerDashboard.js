import React, { useState } from 'react';
import axios from 'axios';
const API = process.env.REACT_APP_API_URL || 'http://localhost:4000/api';
export default function OwnerDashboard(){
  const token = localStorage.getItem('token');
  const [storeId,setStoreId]=useState(''); const [data,setData]=useState(null);
  async function fetch(){ try{ const res = await axios.get(API+`/stores/owner/${storeId}/raters`, { headers: { Authorization: 'Bearer '+token } }); setData(res.data); }catch(e){ alert(e.response?.data?.message||e.message); } }
  return (<div style={{padding:20}}>
    <h3>Owner Dashboard</h3>
    <div><input placeholder='Your store id' value={storeId} onChange={e=>setStoreId(e.target.value)} /> <button onClick={fetch}>Load raters</button></div>
    {data && (<div><div>Average: {data.average}</div><ul>{data.raters.map(r=> <li key={r.userId}>{r.name} ({r.email}) — {r.value}</li>)}</ul></div>)}
  </div>);
}
